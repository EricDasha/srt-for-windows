借鑑了 [字在AnySub](https://microsoftedge.microsoft.com/addons/detail/ehfngpdjbdalmoobgpclakpieocdjhfe)（硬抄）

用於給小窗外掛（例如[弹幕画中画播放器](https://github.com/apades/dmMiniPlayer)掛載字幕文件）

<img width="464" height="297" alt="image" src="https://github.com/user-attachments/assets/35d9e80a-805b-47c5-b1b7-352b6a4f0e68" />
